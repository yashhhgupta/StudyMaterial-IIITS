README
-------------
Survey Question No: 22
Prerequisite: Install Node

Please install the following packages:

npm init
npm install modules
npm install ejs express body-parser

Run the application:
node app

Open the following link
http://localhost:3000/
